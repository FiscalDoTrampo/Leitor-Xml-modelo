$ErrorActionPreference = "Stop"
$ProjectDir = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectDir

Write-Host "[1/4] Verificando Python..."
$Python = Get-Command py -ErrorAction SilentlyContinue
if ($Python) {
    $PythonArgs = @("-3")
    $PythonExe = $Python.Source
} else {
    $Python = Get-Command python -ErrorAction SilentlyContinue
    if (-not $Python) { throw "Python 3 nao foi encontrado. Instale-o marcando Add Python to PATH." }
    $PythonArgs = @()
    $PythonExe = $Python.Source
}

Write-Host "[2/4] Preparando ambiente de compilacao..."
if (-not (Test-Path ".venv-build\Scripts\python.exe")) {
    & $PythonExe @PythonArgs -m venv .venv-build
}
& ".venv-build\Scripts\python.exe" -m pip install --upgrade pip
& ".venv-build\Scripts\python.exe" -m pip install -r requirements-build.txt

Write-Host "[3/4] Gerando aplicativo Windows..."
& ".venv-build\Scripts\python.exe" -m PyInstaller --noconfirm --clean CalculadoraFiscal.spec

Write-Host "[4/4] Gerando instalador..."
$IsccCandidates = @(
    "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe",
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
)
$Iscc = $IsccCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $Iscc) { throw "Inno Setup 6 nao foi encontrado. Instale-o e execute GERAR_INSTALADOR.bat novamente." }

& $Iscc "installer\CalculadoraFiscal.iss"
$Installer = Get-ChildItem "instalador-gerado\Instalador_Calculadora_Fiscal_*.exe" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $Installer) { throw "O arquivo final do instalador nao foi localizado." }
Write-Host "Instalador criado em: $($Installer.FullName)" -ForegroundColor Green
