"""Inicializador desktop da Calculadora Fiscal empacotada."""

from __future__ import annotations

import socket
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

from streamlit.web import bootstrap


def resource_path(relative_path: str) -> Path:
    """Resolve arquivos no projeto e no pacote gerado pelo PyInstaller."""
    base_dir = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base_dir / relative_path


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.bind(("127.0.0.1", 0))
        return int(server.getsockname()[1])


def open_browser_when_ready(url: str) -> None:
    for _ in range(100):
        try:
            with urllib.request.urlopen(url, timeout=0.5):
                webbrowser.open(url)
                return
        except Exception:
            time.sleep(0.1)


def main() -> None:
    app_path = resource_path("app.py")
    if not app_path.exists():
        raise FileNotFoundError(f"Arquivo principal não encontrado: {app_path}")

    port = free_port()
    url = f"http://127.0.0.1:{port}"
    threading.Thread(target=open_browser_when_ready, args=(url,), daemon=True).start()

    bootstrap.run(
        str(app_path),
        is_hello=False,
        args=[],
        flag_options={
            "server.address": "127.0.0.1",
            "server.port": port,
            "server.headless": True,
            "browser.gatherUsageStats": False,
        },
    )


if __name__ == "__main__":
    main()
