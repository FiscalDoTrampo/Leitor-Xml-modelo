@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\gerar_instalador.ps1"
if errorlevel 1 (
  echo.
  echo A geracao do instalador falhou. Consulte as mensagens acima.
  pause
  exit /b 1
)
echo.
echo Processo concluido.
pause
