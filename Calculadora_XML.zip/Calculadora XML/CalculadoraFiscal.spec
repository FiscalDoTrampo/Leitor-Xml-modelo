# -*- mode: python ; coding: utf-8 -*-

from PyInstaller.utils.hooks import collect_all, collect_submodules

streamlit_datas, streamlit_binaries, streamlit_hiddenimports = collect_all("streamlit")

datas = streamlit_datas + [
    ("app.py", "."),
    ("src", "src"),
    ("assets", "assets"),
]

a = Analysis(
    ["launcher.py"],
    pathex=[],
    binaries=streamlit_binaries,
    datas=datas,
    hiddenimports=(streamlit_hiddenimports + collect_submodules("altair") + collect_submodules("pandas") + ["openpyxl", "openpyxl.cell._writer"]),
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["tkinter", "matplotlib", "pytest"],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name="CalculadoraFiscal", debug=False, bootloader_ignore_signals=False, strip=False, upx=True, console=False, disable_windowed_traceback=False, argv_emulation=False, target_arch=None, codesign_identity=None, entitlements_file=None)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=True, upx_exclude=[], name="CalculadoraFiscal")
